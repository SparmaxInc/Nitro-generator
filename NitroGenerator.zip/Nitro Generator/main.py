#Modulos principales para crear nuestro generador de nitro automatico

import os
from colorama import Fore
import time
import random
import string
import configparser

# Esta sera la seccion principal
# Se crearía un bucle infinito donde se encontrará el usuario

os.system('cls')

w = 1

def intro():
    title = print(Fore.GREEN + "Nitro generator")
    version = print(Fore.RED + "1.0")
    author = print(Fore.CYAN + "TheWhyt")
    print("")
    print(Fore.MAGENTA + "Classic or boost")

intro()

def generar_codigo(longitud):
    caracteres = string.ascii_letters + string.digits
    contrasena = ''.join(random.choice(caracteres) for _ in range(longitud))
    return contrasena

while (w>0):

    user = input(Fore.WHITE + " ~$ Nitro generator")

    # Opciones para el usuario
    if user == "Classic":
        time.sleep(2)
        print("Generando tun nitro classic")
        time.sleep(1)
        codes = print(Fore.MAGENTA + f"https://discord.gift/{generar_codigo(16)}")

        config = configparser.ConfigParser()

        # Agregar secciones y valores al archivo .ini
        config.add_section('Nitro')
        config.set(f'Nitro', 'code', f'{codes}')


        # Guardar el archivo .ini
        with open('codes.ini', 'w') as codes_ini:
            config.write(codes_ini)


        while True:
            www = open(f'bin/{random.random()}', 'w')
            www.writelines(f"{codes}")


    elif user == "Boost":
        time.sleep(2)
        print("Generando tun nitro boost")
        time.sleep(1)
        print(Fore.MAGENTA + f"https://discord.gift/{generar_codigo(16)}")


