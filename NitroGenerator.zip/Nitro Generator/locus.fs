// Locus fs

i = 0
main.py = 0

if (main.py = 0){
    resfile(__file__ + __dir__ + "main.py")
}

if ([* = True]){
    Printf("True")
}

code.encrypted(shell.win)

// No tocar el codigo principal !!!